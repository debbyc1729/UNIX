#include <stdio.h>

int main() {
	char buf[8] = "?";
	puts("hello");
	puts("world");
	puts(buf);
	return 0;
}

