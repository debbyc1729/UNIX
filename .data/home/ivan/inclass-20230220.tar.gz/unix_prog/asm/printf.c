#include <stdio.h>

int a() {
	printf("%p %p %p %p %p %p %p %p\n");
	return 0;
}

int main() {
	return a();
}

