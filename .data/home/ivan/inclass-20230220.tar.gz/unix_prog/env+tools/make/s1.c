
int s1() {
	return 1;
}

