#!/bin/bash

while /bin/true; do
	echo ticks ... `date +"%T"`
	sleep 1
done

