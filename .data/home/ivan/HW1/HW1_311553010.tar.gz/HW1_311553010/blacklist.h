#pragma once
#include <vector>
using namespace std;

class blacklist{
public:
    string name_API = "";
    vector<string> rules;
};

blacklist BL[6];