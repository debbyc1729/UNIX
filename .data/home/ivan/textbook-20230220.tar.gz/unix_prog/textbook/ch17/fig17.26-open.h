#include "apue.h"
#include <errno.h>

#define	CL_OPEN "open"			/* client's request for server */

int		csopen(char *, int);
